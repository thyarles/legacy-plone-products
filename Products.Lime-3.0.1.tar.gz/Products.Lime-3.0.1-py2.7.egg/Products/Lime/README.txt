Lime - Link Marshaller
======================

Marshaller(s) for use with ATLink/CMF Link/ATFavorite. Export and
Import both Windows 'Internet Shortcut' and freedesktop.org's
``.desktop`` format.

Installation
------------

Only drop it in your products folder.

Usage
-----

Set the marshaller for your link-like object to use one of the
marshallers included.

