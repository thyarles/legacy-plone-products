ShellExServer
=============

This product provides the server side components for Enfold Desktop.

Dependencies
------------

- setuptools,Products.CMFPlone, Products.ATContentTypes, Products.Archetypes,
  Products.CMFActionIcons, Products.CMFCore, Products.CMFDefault, Products.CMFPropertySets,
  Products.Calendaring, Products.DavPack, Products.Lime, Products.Marshall

- All of these are either standard dependencies in a Plone 4.x install or are 
  released as eggs on Enfold's public distribution server

Installation
------------

- Add Products.ShellExServer to the eggs section of your buildout
  
- add http://dist.enfoldsystems.com/simple to your find-links

- Re-run buildout and then restart Zope

- Install from the Add-Ons section in Site Setup

More information
----------------

- http://www.enfoldsystems.com
