#------------------------------------------------------------------------------#
#   test_doctests.py                                                           #
#                                                                              #
#   Copyright (c) 2010, Enfold Systems, Inc.                                   #
#   All rights reserved.                                                       #
#                                                                              #
#       This software is licensed under the Terms and Conditions               #
#       contained within the "LICENSE.txt" file that accompanied               #
#       this software.  Any inquiries concerning the scope or                  #
#       enforceability of the license should be addressed to:                  #
#                                                                              #
#           Enfold Systems, Inc.                                               #
#           4617 Montrose Blvd., Suite C215                                    #
#           Houston, Texas 77006 USA                                           #
#           p. +1 713.942.2377 | f. +1 832.201.8856                            #
#           www.enfoldsystems.com                                              #
#           info@enfoldsystems.com                                             #
#------------------------------------------------------------------------------#


import os
import sys

# Load fixture
from Testing import ZopeTestCase


def test_suite():
    import unittest
    from Testing.ZopeTestCase import doctest

    suite = unittest.TestSuite()

    try:
        from Products.PloneTestCase.layer import ZCML
        suite.layer = ZCML
    except ImportError:
        pass
    
    FileSuite = doctest.DocFileSuite
    files = [
        'normalization.txt',
        ]
    for f in files:
        suite.addTest(FileSuite(f, package='Products.ShellExServer.tests',
                                optionflags=(doctest.ELLIPSIS |
                                             doctest.NORMALIZE_WHITESPACE |
                                             doctest.REPORT_UDIFF),
                                ))
    return suite
