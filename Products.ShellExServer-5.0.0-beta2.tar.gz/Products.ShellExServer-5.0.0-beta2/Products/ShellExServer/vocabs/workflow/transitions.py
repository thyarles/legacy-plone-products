#------------------------------------------------------------------------------#
#   transitions.py                                                             #
#                                                                              #
#   Copyright (c) 2010, Enfold Systems, Inc.                                   #
#   All rights reserved.                                                       #
#                                                                              #
#       This software is licensed under the Terms and Conditions               #
#       contained within the "LICENSE.txt" file that accompanied               #
#       this software.  Any inquiries concerning the scope or                  #
#       enforceability of the license should be addressed to:                  #
#                                                                              #
#           Enfold Systems, Inc.                                               #
#           4617 Montrose Blvd., Suite C215                                    #
#           Houston, Texas 77006 USA                                           #
#           p. +1 713.942.2377 | f. +1 832.201.8856                            #
#           www.enfoldsystems.com                                              #
#           info@enfoldsystems.com                                             #
#------------------------------------------------------------------------------#


from Acquisition import aq_base
from Globals import InitializeClass
from Products.CMFCore.utils import getToolByName
from Products.CMFPropertySets.interfaces.provider import IVocabularyProvider
from Products.CMFPropertySets.VocabularyProvider import VocabularyProvider
from Products.ShellExServer.utils import listFilteredActionsForCategory
from Products.ShellExServer.vocabs.helpers import Constructor


class Transitions(VocabularyProvider):
    """Available subjects for a content object."""

    id = 'transitions'
    ns = 'http://cmf.zope.org/propsets/dcworkflow'
    propid = 'review_state'

    def getValueFor(self, context):
        wf_tool = getToolByName(context, 'portal_workflow', None)
        if wf_tool is None:
            return ''
        
        res = []
        actions = listFilteredActionsForCategory(wf_tool, context, 
                                                 'workflow', 
                                                 ('portal_workflow',))

        for action in actions['workflow']:
            data = {'label':action['name'],
                    'value':action['id']
                    }
            res.append(self.template % data)
        return '\n'.join(res)

InitializeClass(Transitions)
manage_addTransitions = Constructor(Transitions)
