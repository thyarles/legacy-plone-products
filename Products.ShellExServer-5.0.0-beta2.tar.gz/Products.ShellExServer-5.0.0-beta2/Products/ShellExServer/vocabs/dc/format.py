#------------------------------------------------------------------------------#
#   format.py                                                                  #
#                                                                              #
#   Copyright (c) 2010, Enfold Systems, Inc.                                   #
#   All rights reserved.                                                       #
#                                                                              #
#       This software is licensed under the Terms and Conditions               #
#       contained within the "LICENSE.txt" file that accompanied               #
#       this software.  Any inquiries concerning the scope or                  #
#       enforceability of the license should be addressed to:                  #
#                                                                              #
#           Enfold Systems, Inc.                                               #
#           4617 Montrose Blvd., Suite C215                                    #
#           Houston, Texas 77006 USA                                           #
#           p. +1 713.942.2377 | f. +1 832.201.8856                            #
#           www.enfoldsystems.com                                              #
#           info@enfoldsystems.com                                             #
#------------------------------------------------------------------------------#


from Acquisition import aq_base
from Globals import InitializeClass
from Products.CMFPropertySets.interfaces.provider import IVocabularyProvider
from Products.CMFPropertySets.VocabularyProvider import VocabularyProvider
from Products.CMFCore.utils import getToolByName
from Products.ShellExServer.vocabs.helpers import Constructor


class Format(VocabularyProvider):
    """ Available formats for a content object """

    id = 'format'
    ns = 'http://cmf.zope.org/propsets/dublincore'
    propid = 'format'

    def getValueFor(self, context):
        res = []
        ut = getToolByName(context, 'plone_utils', None)
        if ut is None:
            return ''
        for mime in ut.availableMIMETypes():
            data = {'label':mime,
                    'value':mime
                    }
            res.append(self.template % data)
        return '\n'.join(res)

InitializeClass(Format)
manage_addFormat = Constructor(Format)
