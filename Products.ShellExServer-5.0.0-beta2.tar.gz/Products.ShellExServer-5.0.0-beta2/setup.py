#------------------------------------------------------------------------------#
#   setup.py                                                                   #
#                                                                              #
#   Copyright (c) 2010, Enfold Systems, Inc.                                   #
#   All rights reserved.                                                       #
#                                                                              #
#       This software is licensed under the Terms and Conditions               #
#       contained within the "LICENSE.txt" file that accompanied               #
#       this software.  Any inquiries concerning the scope or                  #
#       enforceability of the license should be addressed to:                  #
#                                                                              #
#           Enfold Systems, Inc.                                               #
#           4617 Montrose Blvd., Suite C215                                    #
#           Houston, Texas 77006 USA                                           #
#           p. +1 713.942.2377 | f. +1 832.201.8856                            #
#           www.enfoldsystems.com                                              #
#           info@enfoldsystems.com                                             #
#------------------------------------------------------------------------------#
import os
from setuptools import setup, find_packages

def read(*path_components):
    return open(os.path.join(
            os.path.dirname(__file__), *path_components)).read().strip()


version = read('Products', 'ShellExServer', 'version.txt')
long_description = ''
for f in ('README.txt', 'CHANGES'):
    long_description += read(f) + '\n\n'


setup(
    name="Products.ShellExServer",
    version=version,
    long_description=long_description,
    description="Server-side support for Enfold Desktop",
    author="Enfold Systems, Inv",
    author_email="info@enfoldsystems.com",
    url="http://dist.enfoldsystems.com/catalog/shellexserver",
    license="ZPL 2.1 (http://www.zope.org/Resources/License/ZPL-2.1)",
    packages=find_packages(),
    namespace_packages=["Products"],
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        "setuptools",
        "Products.CMFPlone",
        "Products.ATContentTypes",
        "Products.Archetypes",
        "Products.CMFActionIcons",
        "Products.CMFCore",
        "Products.CMFDefault",
        "Products.CMFPropertySets",
        "Products.Calendaring",
        "Products.DavPack",
        "Products.Lime",
        "Products.Marshall",
    ],
    classifiers=[
        "Programming Language :: Python",
        "Framework :: Zope2",
        "License :: OSI Approved :: Zope Public License",
        "Operating System :: Microsoft :: Windows",
    ],
    entry_points="""
      # -*- Entry points: -*-
      [z3c.autoinclude.plugin]
      target = plone
      """,
)
