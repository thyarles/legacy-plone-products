"""
$Id: config.py 5213 2011-11-10 18:41:31Z nikolay $
"""
import sys, logging

PROJECTNAME = 'CMFPropertySets'

log = logging.getLogger(PROJECTNAME)
