Text string translations will be added in this folder (gettext .po files).
 